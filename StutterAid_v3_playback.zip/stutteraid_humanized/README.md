# StutterAid – AI Speech Support Application
**Author:** Reda Ghardi (w2064571)  
**Module:** 6COSC023W Computer Science Final Project  
**University:** University of Westminster

---

## What is StutterAid?

StutterAid is a desktop application that helps people who stutter practise and track their speech fluency.  
It records (or accepts uploaded WAV files), runs local stuttering detection, optionally transcribes with OpenAI Whisper, analyses the transcript for disfluency markers, and generates personalised AI coaching feedback.

---

## Project Structure

```
stutteraid/
├── stutteraid_app.py          ← Entry point, GUI, pipeline coordination
├── modules/
│   ├── __init__.py
│   ├── audio_analyzer.py      ← WAV-level stuttering detection
│   ├── text_analyzer.py       ← Transcript disfluency analysis
│   ├── feedback_engine.py     ← Whisper transcription + GPT feedback
│   └── database.py            ← SQLite session storage
├── recordings/                ← Auto-created; stores .wav recordings
├── stutteraid_data.db         ← Auto-created SQLite database
├── requirements.txt
└── README.md
```

---

## Setup & Installation

### 1. Prerequisites

- Python 3.10 or newer
- `pip`

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

> **Windows note:** `pyaudio` sometimes needs a pre-built wheel:
> ```bash
> pip install pipwin
> pipwin install pyaudio
> ```

### 3. Run the app

```bash
python stutteraid_app.py
```

---

## Using the App

### Analyse Tab

1. **Optional – Set OpenAI API Key**  
   Paste your key into the API Key field and click **Set Key**.  
   Required only for Whisper transcription and AI feedback.  
   Audio analysis works without a key.

2. **Record or Upload**  
   - Click **⏺ Start Recording**, speak, then **⏹ Stop Recording**.  
   - Or click **📂 Upload WAV File** to analyse an existing file.

3. **Pipeline stages**  
   The step bar at the top shows real-time progress:  
   `🎙 Record → 📊 Audio → 📝 Transcribe → 🔎 Text → 💬 Feedback`

4. **Results**  
   All four result panels update automatically.

### History Tab

Shows all past sessions with statistics. Colour-coded:  
- 🟥 Red = high severity  
- 🟨 Yellow = moderate  
- 🟩 Green = low / fluent

---

## Detection Methods

| Type | Algorithm | Reference |
|------|-----------|-----------|
| **Blocks** | Silence ≥ 80 ms within a speech region | Guitar (2013) |
| **Prolongations** | Pearson correlation ≥ 0.85 across 30 ms windows | Van Riper (1982) |
| **Sound repetitions** | Correlated 100 ms look-ahead segments | Guitar (2013) |
| **Thresholds** | Adaptive RMS-based (per recording) | — |

Text analysis detects word repetitions, filler words, phrase repetitions, and computes a severity index.

---

## References

- Guitar, B. (2013). *Stuttering: An Integrated Approach to Its Nature and Treatment* (4th ed.). Lippincott Williams & Wilkins.  
- Van Riper, C. (1982). *The Nature of Stuttering*. Prentice Hall.  
- OpenAI. (2024). *Whisper API documentation*. https://platform.openai.com/docs

---

## Notes

- All recordings are saved locally in `recordings/`.  
- The SQLite database (`stutteraid_data.db`) stores session data locally; nothing is sent externally except the audio file to OpenAI Whisper when a key is set.  
- The app degrades gracefully when no API key is provided: audio analysis still runs fully.
