# stutteraid_app.py
# Main GUI + coordination for StutterAid
# Reda Ghardi - w2064571 - 6COSC023W Final Project

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import pyaudio
import wave
import threading
import os
import json
from datetime import datetime

from modules.audio_analyzer  import AudioAnalyzer
from modules.text_analyzer   import TextAnalyzer
from modules.feedback_engine import FeedbackEngine
from modules.database        import SessionDatabase


# colours - sticking to westminster blue + gold roughly
COLOURS = {
    'bg':         '#F0F4F8',
    'surface':    '#FFFFFF',
    'primary':    '#2D6A9F',
    'primary_dk': '#1A4D7A',
    'accent':     '#E8A838',
    'success':    '#27AE60',
    'danger':     '#C0392B',
    'warning':    '#F39C12',
    'text':       '#2C3E50',
    'text_light': '#7F8C8D',
    'border':     '#D5E0EC',
    'rec_active': '#C0392B',
    'tab_bg':     '#E8EFF7',
}
C = COLOURS  # shorthand used everywhere

FONT = 'Segoe UI'


# ---- small helpers --------------------------------------------------------

def make_btn(parent, text, cmd, colour=None, width=None, **kw):
    colour = colour or C['primary']
    b = tk.Button(parent, text=text, command=cmd,
                  bg=colour, fg='white',
                  activebackground=C['primary_dk'], activeforeground='white',
                  relief='flat', cursor='hand2',
                  font=(FONT, 9, 'bold'), padx=14, pady=7, **kw)
    if width:
        b.config(width=width)
    return b


def make_card(parent, title=None, **kw):
    f = tk.LabelFrame(parent, text=title or '',
                      font=(FONT, 9, 'bold'), fg=C['primary'],
                      bg=C['surface'], bd=1, relief='groove',
                      padx=12, pady=8)
    f.pack(fill='x', pady=(0, 10), **kw)
    return f


def lbl(parent, text, size=9, bold=False, colour=None, **kw):
    weight = 'bold' if bold else ''
    return tk.Label(parent, text=text, font=(FONT, size, weight),
                    bg=parent['bg'], fg=colour or C['text'], **kw)


def text_box(parent, height=5, bg='#FAFBFD'):
    t = scrolledtext.ScrolledText(parent, height=height, wrap='word',
                                  font=(FONT, 9), bg=bg, fg=C['text'],
                                  bd=0, relief='flat', state='disabled',
                                  padx=8, pady=6)
    t.pack(fill='both', expand=True)
    return t


def set_text(widget, text):
    widget.config(state='normal')
    widget.delete('1.0', 'end')
    widget.insert('1.0', text)
    widget.config(state='disabled')


# ---- step progress bar (shown during analysis) ----------------------------

class StepBar(tk.Frame):
    STEPS = ['🎙 Record', '📊 Audio', '📝 Transcribe', '🔎 Text', '💬 Feedback']

    def __init__(self, parent):
        super().__init__(parent, bg=C['bg'])
        self._lbls = []
        for i, step in enumerate(self.STEPS):
            l = tk.Label(self, text=step, font=(FONT, 8),
                         bg=C['bg'], fg=C['text_light'], padx=4)
            l.grid(row=0, column=i*2, padx=2)
            self._lbls.append(l)
            if i < len(self.STEPS) - 1:
                tk.Label(self, text='──', bg=C['bg'],
                         fg=C['border']).grid(row=0, column=i*2+1)
        self.reset()

    def set_step(self, idx):
        for i, l in enumerate(self._lbls):
            if i < idx:
                l.config(fg=C['success'])
            elif i == idx:
                l.config(fg=C['warning'])
            else:
                l.config(fg=C['text_light'])

    def reset(self):
        for l in self._lbls:
            l.config(fg=C['text_light'])

    def done(self):
        for l in self._lbls:
            l.config(fg=C['success'])


# ---- history popup --------------------------------------------------------

class HistoryWindow(tk.Toplevel):

    def __init__(self, parent, db):
        super().__init__(parent)
        self.db = db
        self.title("StutterAid – Session History")
        self.geometry("980x620")
        self.configure(bg=C['bg'])
        self._build()
        self._load()

    def _build(self):
        hdr = tk.Frame(self, bg=C['primary'], height=52)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)
        tk.Label(hdr, text="Session History & Progress",
                 font=(FONT, 14, 'bold'), bg=C['primary'], fg='white').pack(pady=14)

        self.stats_frame = tk.Frame(self, bg=C['surface'], pady=10)
        self.stats_frame.pack(fill='x', padx=20, pady=(12, 0))

        container = tk.Frame(self, bg=C['bg'])
        container.pack(fill='both', expand=True, padx=20, pady=12)

        cols = ('ID', 'Date & Time', 'Duration', 'Words',
                'Blocks', 'Prolongations', 'Sound Reps', 'Total', 'Severity')
        vsb = ttk.Scrollbar(container)
        vsb.pack(side='right', fill='y')

        self.tree = ttk.Treeview(container, columns=cols,
                                  show='headings', yscrollcommand=vsb.set)
        vsb.config(command=self.tree.yview)
        self.tree.pack(fill='both', expand=True)

        widths = (40, 155, 75, 60, 65, 100, 85, 65, 70)
        for col, w in zip(cols, widths):
            self.tree.heading(col, text=col, anchor='center')
            self.tree.column(col, width=w, anchor='center', stretch=False)

        self.tree.tag_configure('high',   background='#FDECEA')
        self.tree.tag_configure('medium', background='#FFF8E7')
        self.tree.tag_configure('ok',     background='#F0FBF4')

    def _load(self):
        stats = self.db.get_statistics()
        items = [
            ('Sessions',    stats['total_sessions']),
            ('Blocks',      stats['total_blocks']),
            ('Prolongations', stats['total_prolongations']),
            ('Sound Reps',  stats['total_sound_reps']),
            ('Total Events',stats['total_events']),
            ('Avg Severity',f"{stats['avg_severity']}/100"),
        ]
        for k, v in items:
            box = tk.Frame(self.stats_frame, bg=C['bg'], padx=16, pady=8,
                           relief='groove', bd=1)
            box.pack(side='left', expand=True, fill='x', padx=6)
            tk.Label(box, text=str(v), font=(FONT, 18, 'bold'),
                     bg=C['bg'], fg=C['primary']).pack()
            tk.Label(box, text=k, font=(FONT, 8),
                     bg=C['bg'], fg=C['text_light']).pack()

        for s in self.db.get_all_sessions():
            aud  = json.loads(s.get('audio_analysis') or '{}')
            txt  = json.loads(s.get('text_analysis')  or '{}')
            b    = len(aud.get('blocks', []))
            p    = len(aud.get('prolongations', []))
            r    = len(aud.get('sound_repetitions', []))
            tot  = b + p + r
            sev  = s.get('severity_index', 0) or 0
            dur  = s.get('duration_s', 0) or 0
            tag  = 'high' if sev > 40 else ('medium' if sev > 10 else 'ok')

            self.tree.insert('', 'end', tags=(tag,), values=(
                s['id'], s['timestamp'], f"{dur:.1f}s",
                txt.get('total_words', 0), b, p, r, tot, f"{sev:.1f}",
            ))


# ---- main app -------------------------------------------------------------

class StutterAidApp:

    def __init__(self, root):
        self.root = root
        self._setup_window()

        self.recording    = False
        self.frames       = []
        self.current_file = None
        self.current_trans= None
        self.engine       = None   # FeedbackEngine, set after API key validated

        self.playing      = False  # audio playback state
        self._play_thread = None

        self.db    = SessionDatabase('stutteraid_data.db')
        self.audio = pyaudio.PyAudio()

        self.CHUNK    = 1024
        self.FORMAT   = pyaudio.paInt16
        self.CHANNELS = 1
        self.RATE     = 16000

        self._build_ui()

    def _setup_window(self):
        self.root.title("StutterAid  |  Speech Analysis Application")
        self.root.geometry("1020x760")
        self.root.minsize(820, 600)
        self.root.configure(bg=C['bg'])

        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TNotebook',     background=C['bg'], borderwidth=0)
        style.configure('TNotebook.Tab', background=C['tab_bg'],
                        foreground=C['text'], font=(FONT, 9, 'bold'),
                        padding=(16, 6))
        style.map('TNotebook.Tab',
                  background=[('selected', C['primary'])],
                  foreground=[('selected', 'white')])
        style.configure('Treeview', font=(FONT, 9), rowheight=24,
                        background=C['surface'], fieldbackground=C['surface'],
                        foreground=C['text'])
        style.configure('Treeview.Heading', font=(FONT, 9, 'bold'),
                        background=C['tab_bg'], foreground=C['primary'])
        style.map('Treeview',
                  background=[('selected', C['primary'])],
                  foreground=[('selected', 'white')])

    # --- UI build ----------------------------------------------------------

    def _build_ui(self):
        # header bar
        hdr = tk.Frame(self.root, bg=C['primary'], height=64)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)

        inner = tk.Frame(hdr, bg=C['primary'])
        inner.pack(side='left', padx=20, pady=10)
        tk.Label(inner, text="StutterAid",
                 font=(FONT, 18, 'bold'), bg=C['primary'], fg='white').pack(side='left')
        tk.Label(inner, text="  AI Speech Support Application",
                 font=(FONT, 10), bg=C['primary'], fg='#A8CCE8').pack(side='left', pady=4)
        tk.Label(hdr, text="University of Westminster  ·  w2064571",
                 font=(FONT, 8), bg=C['primary'], fg='#7BAFD4').pack(side='right', padx=20)

        # tabs
        nb = ttk.Notebook(self.root)
        nb.pack(fill='both', expand=True)

        self.tab_analyse = tk.Frame(nb, bg=C['bg'])
        self.tab_history = tk.Frame(nb, bg=C['bg'])
        self.tab_about   = tk.Frame(nb, bg=C['bg'])

        nb.add(self.tab_analyse, text='  🎙 Analyse  ')
        nb.add(self.tab_history, text='  📈 History  ')
        nb.add(self.tab_about,   text='  ℹ About  ')
        nb.bind('<<NotebookTabChanged>>', self._on_tab_change)

        self._build_analyse_tab()
        self._build_history_tab()
        self._build_about_tab()

    def _build_analyse_tab(self):
        tab = self.tab_analyse

        left = tk.Frame(tab, bg=C['bg'], width=300)
        left.pack(side='left', fill='y', padx=(14, 6), pady=14)
        left.pack_propagate(False)

        right = tk.Frame(tab, bg=C['bg'])
        right.pack(side='left', fill='both', expand=True, padx=(0, 14), pady=14)

        self._build_controls(left)
        self._build_results(right)

    def _build_controls(self, parent):
        # api key
        c1 = make_card(parent, "🔑  OpenAI API Key")
        lbl(c1, "Enter your OpenAI API key to enable\nWhisper transcription and AI feedback.",
            colour=C['text_light']).pack(anchor='w', pady=(0, 6))
        self.api_entry = tk.Entry(c1, show='●', width=28,
                                  font=(FONT, 9), relief='solid', bd=1)
        self.api_entry.pack(fill='x', pady=(0, 6))
        row = tk.Frame(c1, bg=C['surface'])
        row.pack(fill='x')
        make_btn(row, "Set Key", self._set_api_key).pack(side='left')
        self.key_status = lbl(row, "  Not set", colour=C['danger'])
        self.key_status.pack(side='left', padx=6)

        # recording controls
        c2 = make_card(parent, "🎙  Recording")
        self.rec_btn = make_btn(c2, "⏺  Start Recording", self._toggle_recording,
                                colour=C['success'])
        self.rec_btn.pack(fill='x', pady=(0, 6))
        make_btn(c2, "📂  Upload WAV File", self._upload_audio,
                 colour=C['primary']).pack(fill='x')
        self.rec_timer = lbl(c2, "", colour=C['danger'])
        self.rec_timer.pack(pady=(4, 0))

        # playback button - hidden until audio is ready
        self.play_btn = make_btn(c2, "▶  Play Recording", self._toggle_playback,
                                 colour=C['accent'])
        # shown after recording/upload completes

        # pipeline status
        c3 = make_card(parent, "⚙  Pipeline Status")
        self.step_bar = StepBar(c3)
        self.step_bar.pack(pady=(4, 8))
        self.status_lbl = lbl(c3, "Ready", colour=C['text_light'])
        self.status_lbl.pack()
        self.pbar = ttk.Progressbar(c3, mode='indeterminate', length=240)
        self.pbar.pack(fill='x', pady=(6, 0))

        # other actions
        c4 = make_card(parent, "📋  Actions")
        make_btn(c4, "📜  View Full History", self._open_history,
                 colour=C['primary']).pack(fill='x', pady=(0, 6))
        make_btn(c4, "🗑  Clear Results", self._clear_results,
                 colour=C['text_light']).pack(fill='x')

    def _build_results(self, parent):
        canvas = tk.Canvas(parent, bg=C['bg'], bd=0, highlightthickness=0)
        vsb = ttk.Scrollbar(parent, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        inner = tk.Frame(canvas, bg=C['bg'])
        wid = canvas.create_window((0, 0), window=inner, anchor='nw')

        inner.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfig(wid, width=e.width))
        canvas.bind_all('<MouseWheel>', lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), 'units'))
        canvas.bind_all('<Button-4>', lambda e: canvas.yview_scroll(-1, 'units'))
        canvas.bind_all('<Button-5>', lambda e: canvas.yview_scroll(1, 'units'))

        # result panels
        c1 = make_card(inner, "📝  Transcript")
        self.trans_box = text_box(c1, height=3, bg='#F7F9FC')

        c2 = make_card(inner, "📊  Audio Analysis  (Blocks · Prolongations · Repetitions)")
        self.audio_box = text_box(c2, height=6, bg='#FFFEF5')

        c3 = make_card(inner, "🔎  Text Disfluency Analysis")
        self.text_box = text_box(c3, height=4, bg='#F7F9FC')

        c4 = make_card(inner, "💬  AI Feedback  (GPT-4o mini + Speech Coaching)")
        self.fb_box = text_box(c4, height=7, bg='#F0FBF4')

    def _build_history_tab(self):
        tab = self.tab_history

        hdr = tk.Frame(tab, bg=C['surface'], pady=12)
        hdr.pack(fill='x', padx=16, pady=(16, 0))
        lbl(hdr, "Session History", size=12, bold=True).pack(side='left')
        make_btn(hdr, "↻ Refresh", self._refresh_history,
                 colour=C['primary']).pack(side='right')

        self.hist_stats = tk.Frame(tab, bg=C['bg'])
        self.hist_stats.pack(fill='x', padx=16, pady=8)

        frame = tk.Frame(tab, bg=C['bg'])
        frame.pack(fill='both', expand=True, padx=16, pady=(0, 16))

        cols = ('ID', 'Date & Time', 'Duration', 'Words',
                'Blocks', 'Prolongations', 'Snd Reps', 'Total', 'Severity')
        vsb = ttk.Scrollbar(frame)
        vsb.pack(side='right', fill='y')
        hsb = ttk.Scrollbar(frame, orient='horizontal')
        hsb.pack(side='bottom', fill='x')

        self.hist_tree = ttk.Treeview(frame, columns=cols, show='headings',
                                       yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.config(command=self.hist_tree.yview)
        hsb.config(command=self.hist_tree.xview)
        self.hist_tree.pack(fill='both', expand=True)

        widths = (40, 155, 75, 60, 65, 100, 85, 65, 70)
        for col, w in zip(cols, widths):
            self.hist_tree.heading(col, text=col, anchor='center')
            self.hist_tree.column(col, width=w, anchor='center', stretch=False)

        self.hist_tree.tag_configure('high',   background='#FDECEA')
        self.hist_tree.tag_configure('medium', background='#FFF8E7')
        self.hist_tree.tag_configure('ok',     background='#F0FBF4')

        self._refresh_history()

    def _refresh_history(self):
        for w in self.hist_stats.winfo_children():
            w.destroy()

        stats = self.db.get_statistics()
        items = [
            ('Sessions',      stats['total_sessions']),
            ('Blocks',        stats['total_blocks']),
            ('Prolongations', stats['total_prolongations']),
            ('Sound Reps',    stats['total_sound_reps']),
            ('Total Events',  stats['total_events']),
            ('Avg Severity',  f"{stats['avg_severity']} / 100"),
        ]
        for k, v in items:
            box = tk.Frame(self.hist_stats, bg=C['surface'],
                           padx=12, pady=8, relief='groove', bd=1)
            box.pack(side='left', expand=True, fill='x', padx=4)
            tk.Label(box, text=str(v), font=(FONT, 16, 'bold'),
                     bg=C['surface'], fg=C['primary']).pack()
            tk.Label(box, text=k, font=(FONT, 8),
                     bg=C['surface'], fg=C['text_light']).pack()

        for row in self.hist_tree.get_children():
            self.hist_tree.delete(row)

        for s in self.db.get_all_sessions():
            aud = json.loads(s.get('audio_analysis') or '{}')
            txt = json.loads(s.get('text_analysis')  or '{}')
            b   = len(aud.get('blocks', []))
            p   = len(aud.get('prolongations', []))
            r   = len(aud.get('sound_repetitions', []))
            tot = b + p + r
            sev = s.get('severity_index', 0) or 0
            dur = s.get('duration_s', 0) or 0
            tag = 'high' if sev > 40 else ('medium' if sev > 10 else 'ok')

            self.hist_tree.insert('', 'end', tags=(tag,), values=(
                s['id'], s['timestamp'], f"{dur:.1f}s",
                txt.get('total_words', 0), b, p, r, tot, f"{sev:.1f}",
            ))

    def _build_about_tab(self):
        tab = self.tab_about
        outer = tk.Frame(tab, bg=C['bg'])
        outer.pack(expand=True, fill='both', padx=60, pady=30)

        lbl(outer, "StutterAid", size=22, bold=True, colour=C['primary']).pack()
        lbl(outer, "AI-Powered Speech Support Application", size=11,
            colour=C['text_light']).pack(pady=(2, 16))

        info = [
            ("Student",    "Reda Ghardi  (w2064571)"),
            ("Module",     "6COSC023W  –  Computer Science Final Project"),
            ("University", "University of Westminster"),
            ("Supervisor", "Aymane El Hajjar"),
            ("Assessor",   "Abhijit Adhikary"),
            ("Version",    "2.0  (Post-IPD)"),
        ]
        tbl = tk.Frame(outer, bg=C['surface'], relief='groove', bd=1)
        tbl.pack(fill='x', pady=8)
        for row, (k, v) in enumerate(info):
            tk.Label(tbl, text=k, font=(FONT, 9, 'bold'), bg=C['surface'],
                     fg=C['text_light'], width=14, anchor='e').grid(
                         row=row, column=0, sticky='e', padx=(16, 6), pady=5)
            tk.Label(tbl, text=v, font=(FONT, 9), bg=C['surface'],
                     fg=C['text'], anchor='w').grid(row=row, column=1, sticky='w', pady=5)

        lbl(outer, "\nDetection Methods", size=10, bold=True,
            colour=C['primary']).pack(anchor='w', pady=(16, 4))
        lbl(outer,
            "• Blocks: sustained silence (≥ 80 ms) inside a speech region\n"
            "• Prolongations: high Pearson correlation across consecutive windows → held sound\n"
            "• Sound repetitions: matching 100 ms segments via correlation look-ahead\n"
            "• Thresholds: adaptive RMS-based (Guitar, 2013)",
            colour=C['text_light']).pack(anchor='w')

        lbl(outer, "\nReferences", size=10, bold=True,
            colour=C['primary']).pack(anchor='w', pady=(12, 4))
        lbl(outer,
            "Guitar, B. (2013). Stuttering: An Integrated Approach to Its Nature and Treatment (4th ed.).\n"
            "Van Riper, C. (1982). The Nature of Stuttering. Prentice Hall.\n"
            "OpenAI (2024). Whisper API & GPT-4o mini documentation.",
            colour=C['text_light']).pack(anchor='w')

    # --- event handlers ----------------------------------------------------

    def _on_tab_change(self, event):
        if event.widget.index('current') == 1:
            self._refresh_history()

    def _set_api_key(self):
        key = self.api_entry.get().strip()
        if not key:
            messagebox.showwarning("API Key", "Please paste your OpenAI API key first.")
            return
        try:
            engine = FeedbackEngine(key)
            engine.client.models.list()
            self.engine = engine
            self.key_status.config(text="  ✔ Active", fg=C['success'])
            self.api_entry.config(show='●', state='disabled')
        except Exception as e:
            messagebox.showerror("API Key Error", f"Could not validate key:\n{e}")
            self.engine = None
            self.key_status.config(text="  ✗ Invalid", fg=C['danger'])

    def _toggle_recording(self):
        if self.recording:
            self._stop_recording()
        else:
            self._start_recording()

    def _start_recording(self):
        self._stop_playback()
        self.recording = True
        self.frames    = []
        self.rec_btn.config(text="⏹  Stop Recording", bg=C['rec_active'])
        self._set_status("Recording in progress…", C['danger'])
        self._rec_start = datetime.now()
        self._update_timer()
        threading.Thread(target=self._record_loop, daemon=True).start()

    def _update_timer(self):
        if self.recording:
            elapsed = (datetime.now() - self._rec_start).seconds
            self.rec_timer.config(text=f"⏱ {elapsed // 60:02d}:{elapsed % 60:02d}")
            self.root.after(1000, self._update_timer)
        else:
            self.rec_timer.config(text="")

    def _record_loop(self):
        try:
            stream = self.audio.open(format=self.FORMAT, channels=self.CHANNELS,
                                     rate=self.RATE, input=True,
                                     frames_per_buffer=self.CHUNK)
            while self.recording:
                self.frames.append(stream.read(self.CHUNK))
            stream.stop_stream()
            stream.close()
        except Exception as e:
            self.recording = False
            self.root.after(0, lambda: messagebox.showerror("Microphone Error", str(e)))

    def _stop_recording(self):
        self.recording = False
        self.rec_btn.config(text="⏺  Start Recording", bg=C['success'])
        self._set_status("Saving recording…", C['warning'])

        os.makedirs("recordings", exist_ok=True)
        ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = f"recordings/recording_{ts}.wav"

        with wave.open(path, 'wb') as wf:
            wf.setnchannels(self.CHANNELS)
            wf.setsampwidth(self.audio.get_sample_size(self.FORMAT))
            wf.setframerate(self.RATE)
            wf.writeframes(b''.join(self.frames))

        self._show_play_btn()
        threading.Thread(target=self._run_pipeline, args=(path,), daemon=True).start()

    def _upload_audio(self):
        path = filedialog.askopenfilename(title="Select WAV file",
                                          filetypes=[("WAV audio", "*.wav"),
                                                     ("All files", "*.*")])
        if path:
            self._show_play_btn()
            threading.Thread(target=self._run_pipeline, args=(path,), daemon=True).start()

    # --- analysis pipeline -------------------------------------------------

    def _run_pipeline(self, audio_file):
        try:
            self._ui(self.pbar.start, 10)
            self._ui(self.step_bar.reset)
            self.current_file = audio_file

            # stage 1 - audio analysis
            self._ui(self._set_status, "Analysing audio signal…", C['danger'])
            self._ui(self.step_bar.set_step, 1)
            analyser  = AudioAnalyzer(audio_file)
            audio_res = analyser.analyze()
            counts    = analyser.summary_counts(audio_res)
            self._ui(set_text, self.audio_box, self._fmt_audio(audio_res, counts))

            transcript = ""
            text_res   = {}

            if self.engine:
                # stage 2 - transcription
                self._ui(self._set_status, "Transcribing with Whisper…", C['primary'])
                self._ui(self.step_bar.set_step, 2)
                try:
                    transcript = self.engine.transcribe(audio_file)
                    self._ui(set_text, self.trans_box, transcript)
                except Exception as e:
                    self._ui(set_text, self.trans_box, f"Transcription failed:\n{e}")
                    transcript = ""

                if transcript:
                    # stage 3 - text analysis
                    self._ui(self._set_status, "Analysing text patterns…", C['warning'])
                    self._ui(self.step_bar.set_step, 3)
                    ta       = TextAnalyzer(transcript)
                    text_res = ta.analyze()
                    self._ui(set_text, self.text_box, self._fmt_text(text_res))

                    # stage 4 - feedback
                    self._ui(self._set_status, "Generating AI feedback…", '#9B59B6')
                    self._ui(self.step_bar.set_step, 4)
                    feedback = self.engine.generate_feedback(transcript, audio_res, text_res)
                    self._ui(set_text, self.fb_box, feedback)
                else:
                    feedback = ""
            else:
                self._ui(set_text, self.trans_box,
                         "ℹ  API key not set.\n"
                         "Audio analysis above is available without a key.\n"
                         "Set your OpenAI API key to enable transcription and feedback.")
                self._ui(set_text, self.fb_box,
                         "ℹ  AI feedback requires an OpenAI API key.")
                feedback = ""

            self.db.save_session(
                audio_file=audio_file,
                duration_s=audio_res.get('duration_s', 0),
                transcription=transcript,
                audio_analysis=audio_res,
                text_analysis=text_res,
                feedback=feedback,
            )

            self._ui(self.step_bar.done)
            self._ui(self._set_status, "✔  Analysis complete", C['success'])

        except Exception as e:
            self._ui(lambda: messagebox.showerror("Error", str(e)))
            self._ui(self._set_status, "✗  An error occurred", C['danger'])
        finally:
            self._ui(self.pbar.stop)

    # --- output formatting -------------------------------------------------

    def _fmt_audio(self, res, counts):
        lines = [
            "AUDIO-BASED STUTTERING DETECTION",
            "=" * 56,
            f"Recording duration : {res.get('duration_s', 0):.2f} s",
            f"Sample rate        : {res.get('sample_rate', 0)} Hz",
            "",
        ]

        if counts['total'] == 0:
            lines += [
                "No significant stuttering events detected.",
                "",
                "Possible reasons:",
                "  • Speech is highly fluent in this sample",
                "  • Recording is too short or quiet",
                "  • Mild stuttering below detection thresholds",
            ]
            return '\n'.join(lines)

        blocks = res['blocks']
        if blocks:
            lines += [
                f"BLOCKS  ({len(blocks)} detected)",
                "  Sudden silence mid-speech — speaker gets 'stuck'",
                "  (Guitar, 2013: tonic blocks)",
                "",
            ]
            for i, ev in enumerate(blocks[:8], 1):
                lines.append(f"  {i:>2}. t={ev['start_time']:.2f}s  "
                             f"dur={ev['duration']:.2f}s  [{ev.get('severity','?')} severity]")
            if len(blocks) > 8:
                lines.append(f"  … and {len(blocks)-8} more")
            lines.append("")

        prols = res['prolongations']
        if prols:
            lines += [
                f"PROLONGATIONS  ({len(prols)} detected)",
                "  Stretched / held sounds  (e.g. 'ssssnake')",
                "",
            ]
            for i, ev in enumerate(prols[:8], 1):
                lines.append(f"  {i:>2}. t={ev['start_time']:.2f}s  "
                             f"dur={ev['duration']:.2f}s  "
                             f"conf={ev.get('confidence','?')}  [{ev.get('severity','?')}]")
            if len(prols) > 8:
                lines.append(f"  … and {len(prols)-8} more")
            lines.append("")

        reps = res['sound_repetitions']
        if reps:
            lines += [
                f"SOUND REPETITIONS  ({len(reps)} detected)",
                "  Repeated syllables  (e.g. 'b-b-ball', 'I-I-I')",
                "",
            ]
            for i, ev in enumerate(reps[:8], 1):
                lines.append(f"  {i:>2}. t={ev['start_time']:.2f}s  "
                             f"dur={ev['duration']:.2f}s  "
                             f"n={ev.get('count','?')} reps  [{ev.get('severity','?')}]")
            if len(reps) > 8:
                lines.append(f"  … and {len(reps)-8} more")
            lines.append("")

        lines += [
            "=" * 56,
            f"TOTAL EVENTS : {counts['total']}",
            f"  Blocks: {counts['blocks']}   "
            f"Prolongations: {counts['prolongations']}   "
            f"Sound reps: {counts['sound_repetitions']}",
        ]

        high_n = sum(1 for cat in res.values()
                     if isinstance(cat, list)
                     for ev in cat if ev.get('severity') == 'high')
        if high_n:
            lines.append(f"  ⚠  High-severity events: {high_n}")

        return '\n'.join(lines)

    def _fmt_text(self, res):
        lines = [
            "TEXT DISFLUENCY ANALYSIS",
            "=" * 44,
            f"Total words    : {res['total_words']}",
            f"Severity index : {res['severity_index']} / 100",
            "",
        ]

        wreps = res.get('word_repetitions', [])
        if wreps:
            lines.append("Word Repetitions:")
            for r in wreps:
                lines.append(f"  • '{r['word']}' × {r['count']}")
            lines.append("")
        else:
            lines += ["Word Repetitions: none detected", ""]

        fillers = res.get('filler_words', [])
        if fillers:
            lines.append("Filler Words:")
            for f in fillers:
                lines.append(f"  • '{f['word']}' × {f['count']}")
            lines.append("")
        else:
            lines += ["Filler Words: none detected", ""]

        phrases = res.get('phrase_repetitions', [])
        if phrases:
            lines.append("Phrase Repetitions:")
            for p in phrases:
                lines.append(f"  • \"{p['phrase']}\" × {p['count']}")

        if res.get('revisions', 0):
            lines.append(f"\nMid-word stoppages (revisions): {res['revisions']}")

        return '\n'.join(lines)

    # --- misc helpers ------------------------------------------------------

    def _show_play_btn(self):
        self.play_btn.pack(fill='x', pady=(6, 0))
        self.play_btn.config(text="▶  Play Recording", bg=C['accent'])
        self.playing = False

    def _toggle_playback(self):
        if self.playing:
            self._stop_playback()
        else:
            self._start_playback()

    def _start_playback(self):
        if not self.current_file or not os.path.exists(self.current_file):
            messagebox.showwarning("Playback", "No audio file to play.")
            return
        self.playing = True
        self.play_btn.config(text="⏹  Stop Playback", bg=C['danger'])
        self._play_thread = threading.Thread(target=self._play_loop, daemon=True)
        self._play_thread.start()

    def _play_loop(self):
        try:
            with wave.open(self.current_file, 'rb') as wf:
                stream = self.audio.open(
                    format=self.audio.get_format_from_width(wf.getsampwidth()),
                    channels=wf.getnchannels(),
                    rate=wf.getframerate(),
                    output=True,
                )
                data = wf.readframes(self.CHUNK)
                while data and self.playing:
                    stream.write(data)
                    data = wf.readframes(self.CHUNK)
                stream.stop_stream()
                stream.close()
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Playback Error", str(e)))
        finally:
            self.playing = False
            self.root.after(0, lambda: self.play_btn.config(
                text="▶  Play Recording", bg=C['accent']))

    def _stop_playback(self):
        self.playing = False  # _play_loop checks this flag and exits

    def _set_status(self, msg, colour=None):
        self.status_lbl.config(text=msg, fg=colour or C['text'])

    def _ui(self, fn, *args):
        self.root.after(0, lambda: fn(*args))

    def _open_history(self):
        HistoryWindow(self.root, self.db)

    def _clear_results(self):
        self._stop_playback()
        self.play_btn.pack_forget()
        for box in (self.trans_box, self.audio_box, self.text_box, self.fb_box):
            set_text(box, "")
        self._set_status("Session cleared. Ready.", C['text_light'])
        self.step_bar.reset()
        self.current_file  = None
        self.current_trans = None

    def __del__(self):
        if hasattr(self, 'audio') and self.audio:
            self.audio.terminate()


def main():
    root = tk.Tk()
    app  = StutterAidApp(root)
    root.protocol("WM_DELETE_WINDOW", root.destroy)
    root.mainloop()


if __name__ == "__main__":
    main()
