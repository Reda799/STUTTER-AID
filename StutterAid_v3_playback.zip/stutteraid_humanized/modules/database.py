# modules/database.py
# SQLite session storage for StutterAid
# Reda Ghardi - w2064571

import sqlite3
import json
from datetime import datetime
from contextlib import contextmanager


_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp        TEXT    NOT NULL,
    audio_file       TEXT,
    duration_s       REAL    DEFAULT 0,
    transcription    TEXT    DEFAULT '',
    audio_analysis   TEXT    DEFAULT '{}',
    text_analysis    TEXT    DEFAULT '{}',
    feedback         TEXT    DEFAULT '',
    severity_index   REAL    DEFAULT 0
);
"""

# migrations for columns added after v1
_MIGRATIONS = [
    "ALTER TABLE sessions ADD COLUMN duration_s REAL DEFAULT 0",
    "ALTER TABLE sessions ADD COLUMN severity_index REAL DEFAULT 0",
    "ALTER TABLE sessions ADD COLUMN text_analysis TEXT DEFAULT '{}'",
]


class SessionDatabase:
    """
    Thin wrapper around the StutterAid SQLite DB.
    Opens/closes a new connection per call so it's safe to use from threads.
    """

    def __init__(self, db_path="stutteraid_data.db"):
        self.db_path = db_path
        self._init_db()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _init_db(self):
        with self._connect() as conn:
            conn.executescript(_SCHEMA)
            existing = {row[1] for row in conn.execute("PRAGMA table_info(sessions)")}
            for sql in _MIGRATIONS:
                col = sql.split("ADD COLUMN")[1].strip().split()[0]
                if col not in existing:
                    try:
                        conn.execute(sql)
                    except sqlite3.OperationalError:
                        pass

    def save_session(self, audio_file, duration_s, transcription,
                     audio_analysis, text_analysis, feedback):
        ts  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sev = text_analysis.get('severity_index', 0.0)
        with self._connect() as conn:
            cur = conn.execute(
                """INSERT INTO sessions
                   (timestamp, audio_file, duration_s, transcription,
                    audio_analysis, text_analysis, feedback, severity_index)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (ts, audio_file, duration_s, transcription,
                 json.dumps(audio_analysis), json.dumps(text_analysis),
                 feedback, sev),
            )
            return cur.lastrowid

    def get_all_sessions(self):
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM sessions ORDER BY id DESC").fetchall()
        return [dict(r) for r in rows]

    def get_session(self, session_id):
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM sessions WHERE id = ?",
                               (session_id,)).fetchone()
        return dict(row) if row else None

    def get_statistics(self):
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT audio_analysis, text_analysis, severity_index, timestamp "
                "FROM sessions ORDER BY id ASC"
            ).fetchall()

        if not rows:
            return {k: 0 for k in ('total_sessions','total_blocks',
                                    'total_prolongations','total_sound_reps',
                                    'total_events')} | {'avg_severity': 0.0, 'trend': []}

        total_b = total_p = total_r = 0
        trend   = []

        for row in rows:
            aud = json.loads(row['audio_analysis'] or '{}')
            b   = len(aud.get('blocks', []))
            p   = len(aud.get('prolongations', []))
            r   = len(aud.get('sound_repetitions', []))
            total_b += b
            total_p += p
            total_r += r
            trend.append({'timestamp': row['timestamp'],
                          'total': b+p+r,
                          'severity': row['severity_index'] or 0.0})

        sevs    = [t['severity'] for t in trend if t['severity'] > 0]
        avg_sev = round(sum(sevs)/len(sevs), 1) if sevs else 0.0

        return {
            'total_sessions':      len(rows),
            'total_blocks':        total_b,
            'total_prolongations': total_p,
            'total_sound_reps':    total_r,
            'total_events':        total_b + total_p + total_r,
            'avg_severity':        avg_sev,
            'trend':               trend,
        }

    def delete_session(self, session_id):
        with self._connect() as conn:
            conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
