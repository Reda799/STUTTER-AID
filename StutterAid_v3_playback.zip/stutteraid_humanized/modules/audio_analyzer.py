# modules/audio_analyzer.py
# WAV-level stuttering detection for StutterAid
# Reda Ghardi - w2064571

import wave
import struct
import math


class AudioAnalyzer:
    """
    Detects three types of stuttering events from a WAV file:
      - blocks       : silence mid-speech (speaker gets stuck)
      - prolongations: held/stretched sounds
      - sound reps   : repeated syllables like b-b-ball

    Thresholds adapt to each recording's overall RMS so it works
    across different mics/room volumes.
    """

    def __init__(self, audio_file):
        self.audio_file = audio_file
        self._load()
        self._set_thresholds()

    def _load(self):
        with wave.open(self.audio_file, 'rb') as wf:
            self.channels     = wf.getnchannels()
            self.sample_width = wf.getsampwidth()
            self.framerate    = wf.getframerate()
            raw = wf.readframes(wf.getnframes())

        if self.sample_width == 2:
            self.samples = list(struct.unpack(f'{len(raw)//2}h', raw))
        else:
            self.samples = list(raw)

        # mix down to mono if stereo
        if self.channels == 2:
            mono = []
            for i in range(0, len(self.samples)-1, 2):
                mono.append((self.samples[i] + self.samples[i+1]) // 2)
            self.samples = mono

        self.duration = len(self.samples) / self.framerate

    def _set_thresholds(self):
        if not self.samples:
            self.silence_threshold = 200
            self.speech_threshold  = 600
            return
        rms = math.sqrt(sum(s*s for s in self.samples) / len(self.samples))
        self.silence_threshold = max(50,  rms * 0.03)
        self.speech_threshold  = max(300, rms * 0.10)

    # -----------------------------------------------------------------------

    def _energy_windows(self, window_ms=10):
        step = int(self.framerate * window_ms / 1000.0)
        times, energies = [], []
        for i in range(0, len(self.samples) - step, step):
            win = self.samples[i:i+step]
            rms = math.sqrt(sum(s*s for s in win) / len(win))
            energies.append(rms)
            times.append(i / self.framerate)
        return times, energies

    @staticmethod
    def _pearson(a, b):
        n = len(a)
        if n == 0 or n != len(b):
            return 0.0
        ma = sum(a)/n
        mb = sum(b)/n
        va = sum((x-ma)**2 for x in a)
        vb = sum((x-mb)**2 for x in b)
        if va < 1 or vb < 1:
            return 0.0
        cov = sum((a[i]-ma)*(b[i]-mb) for i in range(n))
        return abs(cov / math.sqrt(va * vb))

    @staticmethod
    def _merge(events, gap=0.2):
        if not events:
            return []
        events = sorted(events, key=lambda e: e['start_time'])
        merged = [events[0].copy()]
        for ev in events[1:]:
            last = merged[-1]
            if (ev['start_time'] - (last['start_time'] + last['duration'])) < gap \
               and ev['type'] == last['type']:
                last['duration'] = ev['start_time'] + ev['duration'] - last['start_time']
                if 'confidence' in ev and 'confidence' in last:
                    last['confidence'] = max(last['confidence'], ev['confidence'])
            else:
                merged.append(ev.copy())
        return merged

    def _severity(self, dur, low, high):
        if dur >= high:   return 'high'
        if dur >= low:    return 'medium'
        return 'low'

    def _speech_regions(self, times, energies, min_windows=10):
        regions, in_speech, start = [], False, 0
        for i, e in enumerate(energies):
            if e > self.speech_threshold:
                if not in_speech:
                    in_speech, start = True, i
            elif in_speech:
                if i - start >= min_windows:
                    regions.append((start, i))
                in_speech = False
        if in_speech and len(energies) - start >= min_windows:
            regions.append((start, len(energies)))
        return regions

    # -----------------------------------------------------------------------

    def detect_blocks(self):
        times, energies = self._energy_windows(window_ms=20)
        if not energies:
            return []

        regions = self._speech_regions(times, energies)
        blocks  = []
        WIN_S   = 0.02

        for s_start, s_end in regions:
            sil_start = None
            for i in range(s_start, s_end):
                if energies[i] < self.silence_threshold:
                    if sil_start is None:
                        sil_start = i
                else:
                    if sil_start is not None:
                        dur = (i - sil_start) * WIN_S
                        if dur >= 0.08:
                            blocks.append({
                                'start_time': round(times[sil_start], 2),
                                'duration':   round(dur, 2),
                                'type':       'block',
                                'severity':   self._severity(dur, 0.15, 0.30),
                            })
                        sil_start = None

        return blocks

    def detect_prolongations(self):
        WIN_MS   = 30
        WIN_SIZE = int(self.framerate * WIN_MS / 1000.0)
        HOP      = WIN_SIZE // 2
        events   = []
        i        = 0

        while i < len(self.samples) - WIN_SIZE * 3:
            w1 = self.samples[i          : i+WIN_SIZE]
            w2 = self.samples[i+WIN_SIZE : i+WIN_SIZE*2]
            w3 = self.samples[i+WIN_SIZE*2: i+WIN_SIZE*3]

            e1 = math.sqrt(sum(s*s for s in w1) / WIN_SIZE)
            if e1 < self.speech_threshold * 0.8:
                i += HOP
                continue

            r12 = self._pearson(w1, w2)
            r23 = self._pearson(w2, w3)

            if r12 > 0.85 and r23 > 0.85:
                dur = WIN_MS * 3 / 1000.0
                j   = i + WIN_SIZE * 3

                while j < len(self.samples) - WIN_SIZE:
                    nxt = self.samples[j-WIN_SIZE: j]
                    cur = self.samples[j: j+WIN_SIZE]
                    if self._pearson(nxt, cur) > 0.80:
                        dur += WIN_MS / 1000.0
                        j   += WIN_SIZE
                    else:
                        break

                if dur >= 0.12:
                    events.append({
                        'start_time': round(i / self.framerate, 2),
                        'duration':   round(dur, 2),
                        'type':       'prolongation',
                        'confidence': round((r12+r23)/2, 3),
                        'severity':   self._severity(dur, 0.25, 0.50),
                    })
                i = j
                continue

            i += HOP

        return self._merge(events, gap=0.10)

    def detect_sound_repetitions(self):
        SEG_MS   = 100
        SEG_SIZE = int(self.framerate * SEG_MS / 1000.0)
        HOP      = SEG_SIZE // 2
        events   = []
        i        = 0

        while i < len(self.samples) - SEG_SIZE * 3:
            seg1 = self.samples[i: i+SEG_SIZE]
            e1   = math.sqrt(sum(s*s for s in seg1) / SEG_SIZE)

            if e1 < self.speech_threshold * 0.7:
                i += HOP
                continue

            matches  = []
            look_end = min(i + SEG_SIZE*8, len(self.samples) - SEG_SIZE)

            for j in range(i+SEG_SIZE, look_end, SEG_SIZE//4):
                seg2 = self.samples[j: j+SEG_SIZE]
                e2   = math.sqrt(sum(s*s for s in seg2) / SEG_SIZE)
                if e2 > self.speech_threshold * 0.5:
                    if self._pearson(seg1, seg2) > 0.75:
                        matches.append(j)

            if matches:
                last = matches[-1]
                dur  = (last + SEG_SIZE - i) / self.framerate
                events.append({
                    'start_time': round(i / self.framerate, 2),
                    'duration':   round(dur, 2),
                    'type':       'sound_repetition',
                    'count':      len(matches) + 1,
                    'severity':   self._severity(dur, 0.20, 0.50),
                })
                i = last + SEG_SIZE
                continue

            i += HOP

        return self._merge(events, gap=0.15)

    # -----------------------------------------------------------------------

    def analyze(self):
        return {
            'blocks':            self.detect_blocks(),
            'prolongations':     self.detect_prolongations(),
            'sound_repetitions': self.detect_sound_repetitions(),
            'duration_s':        round(self.duration, 2),
            'sample_rate':       self.framerate,
        }

    def summary_counts(self, results):
        b = len(results['blocks'])
        p = len(results['prolongations'])
        r = len(results['sound_repetitions'])
        return {'blocks': b, 'prolongations': p, 'sound_repetitions': r, 'total': b+p+r}
