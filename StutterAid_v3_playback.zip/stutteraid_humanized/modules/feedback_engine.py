# modules/feedback_engine.py
# Whisper transcription + GPT feedback for StutterAid
# Reda Ghardi - w2064571

from openai import OpenAI, AuthenticationError, RateLimitError, APIConnectionError


SYSTEM_PROMPT = (
    "You are StutterAid's compassionate AI speech coach. "
    "You have deep knowledge of stuttering therapy techniques including "
    "easy onset, light articulatory contact, diaphragmatic breathing, "
    "and voluntary stuttering. "
    "Always acknowledge the person's effort first, then give specific, "
    "actionable advice based on the data provided. "
    "Keep your tone warm, encouraging, and non-judgmental. "
    "Use plain, accessible English – avoid clinical jargon."
)


class FeedbackEngine:

    def __init__(self, api_key):
        self.client = OpenAI(api_key=api_key)

    @staticmethod
    def _build_prompt(transcript, audio, text):
        a_counts = {
            'blocks':            len(audio.get('blocks', [])),
            'prolongations':     len(audio.get('prolongations', [])),
            'sound_repetitions': len(audio.get('sound_repetitions', [])),
        }
        total_audio = sum(a_counts.values())

        word_reps = text.get('word_repetitions', [])
        fillers   = text.get('filler_words', [])
        sev_idx   = text.get('severity_index', 0.0)
        n_words   = text.get('total_words', 0)

        if total_audio == 0 and sev_idx < 5:
            fluency_note = "The recording appears highly fluent."
        elif total_audio < 5 and sev_idx < 15:
            fluency_note = "Mild disfluency was detected."
        elif total_audio < 15 or sev_idx < 40:
            fluency_note = "Moderate disfluency was detected."
        else:
            fluency_note = "Significant disfluency was detected."

        filler_str = ", ".join(f"'{f['word']}' ×{f['count']}" for f in fillers[:5]) or "none detected"
        wrep_str   = ", ".join(f"'{r['word']}' ×{r['count']}" for r in word_reps[:5]) or "none detected"

        return f"""SESSION DATA
============
Fluency summary : {fluency_note}
Audio duration  : {audio.get('duration_s', 0):.1f} seconds
Words spoken    : {n_words}
Severity index  : {sev_idx}/100 (text-based estimate)

AUDIO DETECTION RESULTS
-----------------------
Blocks (speech stoppages)   : {a_counts['blocks']}
Prolongations (held sounds) : {a_counts['prolongations']}
Sound repetitions           : {a_counts['sound_repetitions']}
Total audio events          : {total_audio}

TEXT ANALYSIS RESULTS
---------------------
Word repetitions : {wrep_str}
Filler words     : {filler_str}

TRANSCRIPT
----------
"{transcript}"

INSTRUCTIONS
------------
1. Open with one sentence acknowledging effort.
2. Name the 1-2 most prominent patterns detected above with plain explanations.
3. Give exactly 3 numbered, concrete therapy techniques matched to those patterns.
4. Close with one motivational sentence.
Keep total response under 300 words."""

    def generate_feedback(self, transcript, audio_results, text_results):
        prompt = self._build_prompt(transcript, audio_results, text_results)
        try:
            resp = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user",   "content": prompt},
                ],
                max_tokens=500,
                temperature=0.65,
            )
            return resp.choices[0].message.content.strip()

        except AuthenticationError:
            return "⚠ API Error: Invalid API key.\nPlease enter a valid OpenAI key in Settings."
        except RateLimitError:
            return "⚠ API Error: Rate limit or quota exceeded.\nPlease wait a moment or add credits at platform.openai.com."
        except APIConnectionError:
            return "⚠ Connection Error: Could not reach OpenAI.\nPlease check your internet connection."
        except Exception as e:
            return f"⚠ Feedback unavailable: {e}"

    def transcribe(self, audio_file):
        with open(audio_file, 'rb') as f:
            result = self.client.audio.transcriptions.create(
                model="whisper-1",
                file=f,
                response_format="text",
                prompt=(
                    "This speech may contain stuttering such as 'I I I want' "
                    "or 'ssssso'. Transcribe every word exactly as spoken, "
                    "preserving all repetitions and disfluencies."
                ),
            )
        return result.strip() if isinstance(result, str) else result.text.strip()
