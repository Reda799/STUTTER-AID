# modules/text_analyzer.py
# Transcript disfluency analysis for StutterAid
# Reda Ghardi - w2064571

import re
from collections import Counter


# filler words / interjections common in stuttering (Van Riper, 1982)
FILLERS = [
    'um', 'uh', 'er', 'ah', 'hmm', 'mm',
    'like', 'basically', 'actually', 'right',
    'you know', 'i mean', 'kind of', 'sort of',
]


class TextAnalyzer:

    def __init__(self, transcript):
        self.raw    = transcript.strip()
        self._words = re.findall(r'\b\w+\b', self.raw.lower())

    def _word_reps(self):
        found = []
        words = self._words
        i = 0
        while i < len(words) - 1:
            if len(words[i]) >= 2 and words[i] == words[i+1]:
                count, j = 2, i+2
                while j < len(words) and words[j] == words[i]:
                    count += 1
                    j     += 1
                found.append({'word': words[i], 'count': count, 'position': i})
                i = j
            else:
                i += 1
        return found

    def _phrase_reps(self):
        words   = self._words
        bigrams = [f"{words[i]} {words[i+1]}" for i in range(len(words)-1)]
        counts  = Counter(bigrams)
        return [{'phrase': p, 'count': c} for p, c in counts.items() if c >= 2]

    def _fillers(self):
        text = self.raw.lower()
        out  = []
        for f in FILLERS:
            if ' ' in f:
                n = text.count(f)
            else:
                n = len(re.findall(rf'\b{re.escape(f)}\b', text))
            if n:
                out.append({'word': f, 'count': n})
        return sorted(out, key=lambda x: -x['count'])

    def _revisions(self):
        # words ending with a hyphen = mid-word stoppage, sometimes in whisper output
        return len(re.findall(r'\b\w+-\b', self.raw))

    def _pauses(self):
        return self.raw.count('...') + self.raw.count('--')

    def _severity(self, word_reps, fillers, total_words):
        if total_words == 0:
            return 0.0
        rep_total    = sum(r['count']-1 for r in word_reps)
        filler_total = sum(f['count'] for f in fillers)
        score = (rep_total * 3 + filler_total) / total_words * 100
        return round(min(score, 100.0), 1)

    def analyze(self):
        word_reps   = self._word_reps()
        phrase_reps = self._phrase_reps()
        fillers     = self._fillers()
        revisions   = self._revisions()
        pauses      = self._pauses()
        total       = len(self._words)
        sev         = self._severity(word_reps, fillers, total)

        return {
            'total_words':        total,
            'word_repetitions':   word_reps,
            'phrase_repetitions': phrase_reps,
            'filler_words':       fillers,
            'revisions':          revisions,
            'pauses':             pauses,
            'severity_index':     sev,
        }
